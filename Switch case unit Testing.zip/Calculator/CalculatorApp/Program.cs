﻿namespace CalculatorApp.Services
{
    public class program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("----Calculator---");
            SimpleCalculator calculator = new SimpleCalculator();
            
                int optionSelected = calculator.CalcultorOptions();
            Console.WriteLine("Please enter the inputs");
                double firstNumber = Convert.ToDouble(Console.ReadLine());
                double secondNumber = Convert.ToDouble(Console.ReadLine());
           
            double result = calculator.calculate(optionSelected, firstNumber, secondNumber);

            Console.WriteLine("The result is {0}",result);

        }
    }
}