﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorApp.Services
{
    public class SimpleCalculator: ISimpleCalculator
    {
        public int CalcultorOptions()
        {

            Console.WriteLine("Please select the below options");
            Console.WriteLine("1.Addition\n2.Subtraction\n3.Multiplication\n4.Division");
            int value = 0;
            try
            {
                int userInput = Convert.ToInt32(Console.ReadLine());
                value = userInput;
            }
            catch (Exception ex) 
            {
                Console.WriteLine("Enter option in numeric");
                CalcultorOptions();
            }
            return value;
        }


        public double calculate(int option, double firstNumber, double secondNumber)
        {
            double result;

            switch (option)
            {

                case 1:
                    result = firstNumber + secondNumber;
                    break;
                case 2:
                    result = firstNumber - secondNumber;
                    break;
                case 3:
                    result = firstNumber * secondNumber;
                    break;
                case 4:
                    if (secondNumber == 0)
                    {
                        throw new ArgumentNullException();
                    }
                    result = firstNumber / secondNumber;

                    break;

                default:
                    throw new InvalidOperationException("Specified operation is not recognized");

            }
            return result;
        }

    }
}
