using CalculatorApp.Services;
using Org.BouncyCastle.Asn1.Mozilla;

namespace Calculator.Tests
{
    
    public class SimpleCalculatorTests
    {
        private readonly SimpleCalculator _simpleCalculator = new SimpleCalculator();
        [Fact]
        public void AddTwoNumbers()
        {
            double num1=3;
            double num2=5;
            double result = _simpleCalculator.calculate(1, num1, num2);
            Assert.Equal(8, result);

        }

        [Fact]
        public void SubtractTwoNumbers()
        {
            double num1 = 10;
            double num2 = 1;
            double result = _simpleCalculator.calculate(2, num1, num2);
           Assert.Equal(9, result);
        }
        [Fact]
        public void MultiplyTwoNumbers()
        {
            double num1 = 5;
            double num2 = 6;
            double result = _simpleCalculator.calculate(3, num1, num2);
            Assert.Equal(30, result);
        }
        [Fact]
        public void DivideTwoNumbers()
        {
            double num1 = 56;
            double num2 = 7;
            double result = _simpleCalculator.calculate(4, num1, num2);
            Assert.Equal(8, result);
        }
        
    }
}