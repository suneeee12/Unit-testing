using mathoperations;



namespace XUnitTestProject
{
    public class UnitTest1
    {

        MyCalculation objMyCal = new MyCalculation();
        [Fact]
        public void TestingAddition()
        {
            int a = 10;
            int b = 20;
            int c = a + b;
            Assert.Equal(30,c);
        }

        [Fact]
        public void TestingSubtraction()
        {
            int a = 20;
            int b = 20;
            int c = a - b;
            Assert.Equal(0, c);
        }
       
        [Fact]
        public void TestingMultiplication()
        {
            int a = 20;
            int b = 20;
            int c = a * b;
            Assert.Equal(400, c);
        }
       
        [Fact]
        public void TestingDivision()
        {
            int a = 20;
            int b = 2;
            int c = a / b;
            Assert.Equal(10, c);
        }
    }
}