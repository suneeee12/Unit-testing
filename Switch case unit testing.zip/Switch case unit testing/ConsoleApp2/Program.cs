﻿using mathoperations;
using System;
namespace Calculater
{
    public class Program
    {
        static void Main(string[] args)
        {
            int res;

            Console.WriteLine ("enter first num:");
            int a=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter second num");
            int b=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter symbol(/,*,+,-):");
            string symbol=Console.ReadLine();

            switch( symbol)
            {
                case "+":
                    res=a+b;
                    Console.WriteLine("Addition:" +res); break;
                case "-":
                    res=a-b;
                    Console.WriteLine("Subtraction:" +res); break;
                case "*": 
                    res=a*b;
                    Console.WriteLine("Multiplication:" +res); break;
                case "/": 
                    res=a/b;
                    Console.WriteLine("Division:" +res); break;
                default:
                    Console.WriteLine("wrong result");
                    break;

            }
            Console.ReadLine();

        }
    }
}

