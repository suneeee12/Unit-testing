﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockingSevice
{
    public class Repository : IRepository
    {
        public List<Student> GetStudentDetails()
        {
            var listOfStudent = new List<Student>();
            //listOfStudent.Add(new Student
            //{
            //    StudentID = 174,
            //    Name = "Bhudevi Dobbala",
            //    MailID = "bhudevi0924@gmail.com",
            //    PhoneNumber = 1236547898
            //});

            return listOfStudent;
        }

    }
}
