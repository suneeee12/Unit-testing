using MockingSevice;
using Moq;

namespace MockingServiceTests
{
    public class StudentControllerTests
    {
        [Fact]
        public void StudentControllerTest()
        {
            Mock<Repository> mockRepository = new Mock<Repository>();
            var student = new StudentController(mockRepository.Object);

            
            Assert.NotNull(student);

        }
    }
}