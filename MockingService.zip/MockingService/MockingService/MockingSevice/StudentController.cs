﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockingSevice
{
    public class StudentController
    {
        IRepository Repository;

        public StudentController(IRepository repository)
        {
            Repository = repository;
        }
    }
}
