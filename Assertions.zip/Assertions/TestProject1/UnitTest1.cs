using Microsoft.VisualStudio.TestPlatform.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework.Internal;
using System.Text;

namespace TestProject1
{
    public class UnitTest1
    {

        [TestMethod()]
        [Fact]
        public void TestMapper()
        {
            var greeting = "Hello";

            //use this
            StringAssert.Contains(greeting, "Hello");


        }
        [Fact]
        public void concatingTheString()
        {
            var greetings = "Hi Socrates, why are you here?";
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.IsTrue(greetings.Contains("Hi"));

        }
        [TestMethod()]
        [Fact]
        public void StartsWith()
            {
            var message = "1234 Hello";

            StringAssert.StartsWith(message, "1234");
           
            }
        public void EndswithMethod()
        {
            var sb = new StringBuilder();
            sb.AppendLine("1234");
            sb.AppendLine("00");
            var message = sb.ToString();

            StringAssert.EndsWith(message, $"00{Environment.NewLine}");
        }


    }
}



