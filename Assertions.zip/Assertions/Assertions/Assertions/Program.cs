﻿class Program
    {
    public static void Main()
    {
        Program obj = new Program();
        obj.AssertionMethod();
    }
    public  void AssertionMethod()
    {
        Console.WriteLine("helo");
    }

}
