using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework.Internal;
using System.Text;

namespace AssertionTesting
{
    public class AssertionTestingMethods
    {

        [TestMethod()]
        [Fact]
        public void TestMapperMethod()
        {
            var greeting = "Hello";

            //use this
            StringAssert.Contains(greeting, "Hello");


        }
        [Fact]
        public void ConcatingTheStringMethod()
        {
            var greetings = "Hi Socrates, why are you here?";
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.IsTrue(greetings.Contains("Hi"));

        }
        [TestMethod()]
        [Fact]
        public void StartsWithMethod()
            {
            var message = "1234 Hello";

            StringAssert.StartsWith(message, "1234");
           
            }
        protected void EndswithMethod()
        {
            var sb = new StringBuilder();
            sb.AppendLine("1234");
            sb.AppendLine("00");
            var message = sb.ToString();

            StringAssert.EndsWith(message, $"00{Environment.NewLine}");
        }
    }
}



