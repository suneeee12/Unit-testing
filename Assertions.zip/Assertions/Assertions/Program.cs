﻿class Program
    {
    public static void Main()
    {
        Program obj = new Program();
        obj.method();
    }
    public  void method()
    {
        Console.WriteLine("helo");
    }

}
