﻿$(document).ready(function () {

   
});

function SaveEmployeeDetails() {
    var employeeName = $('#ename').val();
    var employeeRole = $('#role').val();
    var employeeSalary = $('#salary').val();


    if (employeeName == '' || employeeName == undefined || employeeName == '') {
        $('#errorMessage').text('Name connot be blank!').css('color', 'red');
        return false;
    }
    if (employeeRole == '' || employeeRole == undefined || employeeRole == '') {
        $('#errorMessage').text('Name connot be blank!').css('color', 'red');;
        return false;
    }
    if (employeeSalary == '' || employeeSalary == undefined || employeeSalary == '') {
        $('#errorMessage').text('Name connot be blank!').css('color', 'red');;
        return false;
    }

    var form = document.createElement("FORM");
    var formData = new FormData(form);
    formData.append("EmployeeName", employeeName);
    formData.append("EmployeeRole", employeeRole);
    formData.append("EmployeeSalary", employeeSalary);

    var loadFromURL = "/Employee/Save";


    $.ajax({
        type: "POST",
        url: loadFromURL,
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            if (response.isSuccess == true) {
                swal({
                    title: "Saved!",
                    text: "Your record is saved Successfully",
                    type: "success",
                }).then(function () {
                    window.location.href = '/Employee/Index';
                });
            }
        },
        failure: function (response) {
            swal("Oops", "We couldn't connect to the server!", "error");
            return false;
        }
    });
}

function ValidateNumericFeilds(e) {
    let key = e.key;
    let regex = new RegExp("[^0-9]$");
    if (regex.test(key)) {
        e.preventDefault();
        return false;
    }
}

function ValidatetextFeilds(e) {
    let key = e.key;
    let regex = new RegExp("[^a-zA-Z]$");
    if (regex.test(key)) {
        e.preventDefault();
        return false;
    }
}


function UpdateEmployeeDetails() {
    var employeeName = $('#ename').val();
    var employeeRole = $('#role').val();
    var employeeSalary = $('#salary').val();
    var employeeId = $('#EmployeeId').val();

    if (employeeName == '' || employeeName == undefined || employeeName == '') {
        $('#errorMessage').text('Name connot be blank!').css('color', 'red');
        return false;
    }
    if (employeeRole == '' || employeeRole == undefined || employeeRole == '') {
        $('#errorMessage').text('Name connot be blank!').css('color', 'red');;
        return false;
    }
    if (employeeSalary == '' || employeeSalary == undefined || employeeSalary == '') {
        $('#errorMessage').text('Name connot be blank!').css('color', 'red');;
        return false;
    }

    var form = document.createElement("FORM");
    var formData = new FormData(form);
    formData.append("EmployeeId", employeeId);
    formData.append("EmployeeName", employeeName);
    formData.append("EmployeeRole", employeeRole);
    formData.append("EmployeeSalary", employeeSalary);

    var loadFromURL = "/Employee/Update";


    $.ajax({
        type: "POST",
        url: loadFromURL,
        data: formData,
        contentType: false,
        processData: false,
        success: function (response) {
            if (response.isSuccess == true) {
                swal({
                    title: "Updated!",
                    text: "Your record is Updated Successfully",
                    type: "success",
                }).then(function () {
                    window.location.href = '/Employee/Index';
                });
            }
        },
        failure: function (response) {
            swal("Oops", "We couldn't connect to the server!", "error");
            return false;
        }
    });
}

$('#ename,#role,#salary').change(function () {
    $('#errorMessage').text('');
});


