﻿$(document).ready(function () {

    function SaveEmployeeDetails() {
        debugger;
        var employeeName = $('#ename').val();
        var employeeRole = $('#role').val();
        var employeeSalary = $('#salary').val();


        if (employeeName == '' || employeeName == undefined || employeeName == '') {
            $('#errorMessage').text('Name connot be blank!');
            return false;
        }
        if (employeeRole == '' || employeeRole == undefined || employeeRole == '') {
            $('#errorMessage').text('Name connot be blank!');
            return false;
        }
        if (employeeSalary == '' || employeeSalary == undefined || employeeSalary == '') {
            $('#errorMessage').text('Name connot be blank!');
            return false;
        }


        var form = document.createElement("FORM");
        var formData = new FormData(form);
        formData.append("EmployeeName", employeeName);
        formData.append("EmployeeRole", employeeRole);
        formData.append("EmployeeSalary", employeeSalary);

        $.ajax({
            type: "POST",
            url: '@Url.Content("~/Employee/Save")',
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                window.location.href = '/Employee/Index';
            },
            failure: function (response) {
                alert("Error reaching the server..............");
            }
        });


    }
});