﻿using CRUD.DataLayer;
using CRUD.DataLayer.Models;
using CRUD.RepositoryLayer.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.RepositoryLayer
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly CRUDContext _context;

        public EmployeeRepository(CRUDContext context)
        {
            _context = context;
        }

        public List<Employee> GetEmployeesDetailsList()
        {
            return _context.Employee.ToList();
        }


        public string SaveEmployeeDetails(Employee employee)
        {
            string message = string.Empty;
            try
            {
                if (employee != null)
                {                  
                    _context.Employee.Add(employee);
                    _context.SaveChanges();

                    return message;
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }

            return message;
        }


        public Employee GetEmployeesDetail(int Id)
        {
            return _context.Employee.FirstOrDefault(x => x.Id == Id);

        }


        public string UpdateEmployeeDetails(Employee employee)
        {
            string message = string.Empty;
            try
            {
                if (employee != null)
                {
                    var updateEmployee = _context.Employee.FirstOrDefault(x => x.Id == employee.Id);

                    updateEmployee.Name = employee.Name;
                    updateEmployee.Role = employee.Role;
                    updateEmployee.Salary = employee.Salary;

                    _context.Employee.Update(updateEmployee);
                    _context.SaveChanges();

                    return message;
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }

            return message;
        }


        public void DeleteEmployee(int Id)
        {

            var removeEmployee = _context.Employee.FirstOrDefault(x => x.Id == Id);

            if (removeEmployee != null)
            {
                _context.Employee.Remove(removeEmployee);

                _context.SaveChanges();
            }


        }

    }
}
