﻿using CRUD.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.RepositoryLayer.Interface
{
     public interface IEmployeeRepository
    {
        List<Employee> GetEmployeesDetailsList();
        string SaveEmployeeDetails(Employee employee);
        public Employee GetEmployeesDetail(int Id);
        public string UpdateEmployeeDetails(Employee employee);
        public void DeleteEmployee(int Id);
    }
}
