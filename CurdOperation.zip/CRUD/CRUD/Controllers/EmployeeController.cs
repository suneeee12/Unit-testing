﻿using CRUD.BusinessLayer.Interface;
using CRUD.DataLayer;
using CRUD.DataLayer.Models;
using CRUD.Helper;
using CRUD.Models;
using CRUD.RepositoryLayer;
using CRUD.RepositoryLayer.Interface;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeBusiness _employeeBusiness;
        
        public EmployeeController(IEmployeeBusiness employeeBusines)
        {
            _employeeBusiness = employeeBusines;
        }


        public IActionResult Index()
        {
            return View(_employeeBusiness.GetEmployeesDetailsList());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int Id)
        {
            return base.View(_employeeBusiness.GetEmployeesDetail(Id));
        }

        [HttpPost]
        public IActionResult Save(EmployeeViewModel employeeViewModel)
        {
            string message = string.Empty;
            try
            {
                message = _employeeBusiness.SaveEmployeeDetails(employeeViewModel);

                return Json(new AjaxResponse { IsSuccess = true, Message = message });
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }

            return Json(new AjaxResponse { Message = message });
        }

        [HttpPost]
        public IActionResult Update(EmployeeViewModel employeeViewModel)
        {
            string message = string.Empty;
            try
            {
                message = _employeeBusiness.UpdateEmployeeDetails(employeeViewModel);

                return Json(new AjaxResponse { IsSuccess = true, Message = message });
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }

            return Json(new AjaxResponse { Message = message });
        }

        [HttpGet]
        public IActionResult Delete(int Id)
        {
            _employeeBusiness.DeleteEmployee(Id);
            ViewBag.Messsage = "Record Delete Successfully";
            return RedirectToAction("index");
        }

        [HttpGet]
        public IActionResult Detail(int Id)
        {
            return base.View(_employeeBusiness.GetEmployeesDetail(Id));
        }
    }
}
