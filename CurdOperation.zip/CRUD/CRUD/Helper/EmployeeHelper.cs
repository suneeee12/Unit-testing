﻿using CRUD.DataLayer;
using CRUD.DataLayer.Models;
using CRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Helper
{
    public static class EmployeeHelper
    {

        public static Employee ViewModelObjectToModelObject(EmployeeViewModel employeeDetail)
        {
            Employee employee = new Employee()
            {
                Id = employeeDetail.EmployeeId,
                Name = employeeDetail.EmployeeName,
                Role = employeeDetail.EmployeeRole,
                Salary = employeeDetail.EmployeeSalary
            };

            return employee;
        }

        public static EmployeeViewModel ModelObjectToViewModelObject(Employee employee)
        {
            EmployeeViewModel employeeDetail = new EmployeeViewModel()
            {
            EmployeeId = employee.Id,
            EmployeeName = employee.Name,
            EmployeeRole = employee.Role,
            EmployeeSalary = employee.Salary,
        };
            return employeeDetail;
        }

        public static List<EmployeeViewModel> ModelObjectListToViewModelObjectList(List<Employee> employees)
        {
            List<EmployeeViewModel> employeeDetailList = new List<EmployeeViewModel>();

            foreach(var employee in employees)
            {
                var employeeDetail = new EmployeeViewModel();
                employeeDetail.EmployeeId = employee.Id;
                employeeDetail.EmployeeName = employee.Name;
                employeeDetail.EmployeeRole = employee.Role;
                employeeDetail.EmployeeSalary = employee.Salary;
                employeeDetailList.Add(employeeDetail);
            }
           
            return employeeDetailList;
        }

        public static List<Employee> ViewModelObjectListToModelObjectList(List<EmployeeViewModel> employeeDetailList)
        {
            List<Employee> employeeList = new List<Employee>();

            foreach(var employeeDetail in employeeDetailList)
            {
                Employee employee = new Employee()
                {
                    Name = employeeDetail.EmployeeName,
                    Role = employeeDetail.EmployeeRole,
                    Salary = employeeDetail.EmployeeSalary
                };

                employeeList.Add(employee);
            }
            return employeeList;
        }


    }
}
