﻿using CRUD.DataLayer;
using CRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.BusinessLayer.Interface
{
    public interface IEmployeeBusiness
    {
        public List<EmployeeViewModel> GetEmployeesDetailsList();
        public string SaveEmployeeDetails(EmployeeViewModel employeeDetails);
        public EmployeeViewModel GetEmployeesDetail(int Id);
        public string UpdateEmployeeDetails(EmployeeViewModel employeeDetail);
        public void DeleteEmployee(int Id);
    }
}
