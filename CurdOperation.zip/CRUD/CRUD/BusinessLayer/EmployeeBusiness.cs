﻿using CRUD.BusinessLayer.Interface;
using CRUD.DataLayer;
using CRUD.DataLayer.Models;
using CRUD.Helper;
using CRUD.Models;
using CRUD.RepositoryLayer;
using CRUD.RepositoryLayer.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.BusinessLayer
{
    public class EmployeeBusiness : IEmployeeBusiness
    {
        private readonly IEmployeeRepository _employeeRepository;
        public EmployeeBusiness(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        public  List<EmployeeViewModel> GetEmployeesDetailsList()
        {
            return EmployeeHelper.ModelObjectListToViewModelObjectList(_employeeRepository.GetEmployeesDetailsList());

        }

        public  string SaveEmployeeDetails(EmployeeViewModel employeeDetails)
        {
            string message = string.Empty;
            try
            {
                if (employeeDetails != null)
                {
                   
                    return _employeeRepository.SaveEmployeeDetails(EmployeeHelper.ViewModelObjectToModelObject(employeeDetails));
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }

            return message;
        }

        public  EmployeeViewModel GetEmployeesDetail(int Id)
        {
            return EmployeeHelper.ModelObjectToViewModelObject(_employeeRepository.GetEmployeesDetail(Id));

        }


        public  string UpdateEmployeeDetails(EmployeeViewModel employeeDetail)
        {
            string message = string.Empty;
            try
            {
                if (employeeDetail != null)
                {
                    return _employeeRepository.UpdateEmployeeDetails(EmployeeHelper.ViewModelObjectToModelObject(employeeDetail));
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
            }

            return message;
        }

        public  void DeleteEmployee(int Id)
        {
            _employeeRepository.DeleteEmployee(Id);
        }
    }
}
