﻿using CRUD.DataLayer.Models;
using CRUD.RepositoryLayer.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleMockTest.Model
{
    public class InMemoryEmployeeRepository : IEmployeeRepository
    {
        public InMemoryEmployeeRepository()
        {

        }

        private List<Employee> _db = new List<Employee>()
        {
            new Employee {Id = 1,Name = "Venkatesh Kandregula", Role = "Developer", Salary = 26000},
            new Employee {Id = 2,Name = "Goutham Jampula", Role = "Developer", Salary = 30000},
            new Employee {Id = 3,Name = "Charan Neermula", Role = "Developer", Salary = 26000}
        };

        public void DeleteEmployee(int Id)
        {
            _db.Remove(GetEmployeesDetail(Id));
        }

        public Employee GetEmployeesDetail(int Id)
        {
            return _db.FirstOrDefault(x => x.Id == Id);
        }

        public List<Employee> GetEmployeesDetailsList()
        {
            return _db.ToList();
        }

        public string SaveEmployeeDetails(Employee employee)
        {
            _db.Add(employee);

            return "";
        }

        public string UpdateEmployeeDetails(Employee employee)
        {
            var employeeToUpdate = GetEmployeesDetail(employee.Id);

            _db.Remove(employeeToUpdate);
            _db.Add(employee);

            return "";
        }
    }
}
