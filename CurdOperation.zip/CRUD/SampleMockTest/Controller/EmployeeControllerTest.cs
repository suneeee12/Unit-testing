﻿using CRUD.BusinessLayer.Interface;
using CRUD.Controllers;
using CRUD.DataLayer.Models;
using CRUD.RepositoryLayer.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using SampleMockTest.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleMockTest.Controller
{
    [TestClass]
    public class EmployeeControllerTest
    {
        public TestContext TestContext { get; set; }

        public InMemoryEmployeeRepository MockEmployeeRepository = new InMemoryEmployeeRepository();


        [TestMethod]
        public void TestMethod1()
        {

            List<Employee> employees = new List<Employee>
            {
            new Employee {Id = 1,Name = "Venkatesh Kandregula", Role = "Developer", Salary = 26000},
            new Employee {Id = 2,Name = "Goutham Jampula", Role = "Developer", Salary = 30000},
            new Employee {Id = 3,Name = "Charan Neermula", Role = "Developer", Salary = 26000}
            };



            Mock<IEmployeeRepository> mockEmployeeRepository = new Mock<IEmployeeRepository>();




            mockEmployeeRepository.Setup(mr => mr.GetEmployeesDetailsList()).Returns(employees);



            mockEmployeeRepository.Setup(mr => mr.GetEmployeesDetail(It.IsAny<int>())).Returns((int i) => employees.FirstOrDefault(e => e.Id == i));




            // Allows us to test saving a product
            mockEmployeeRepository.Setup(mr => mr.SaveEmployeeDetails(It.IsAny<Employee>())).Returns(
                (Employee target) =>
                {
                    
                    if (target.Id.Equals(default(int)))
                    {
                        target.Id = employees.Count() + 1;
                        employees.Add(target);
                    }
                    else
                    {
                        var original = employees.FirstOrDefault(
                            q => q.Id == target.Id);



                        if (original == null)
                        {
                            return "";
                        }



                        original.Name = target.Name;
                        original.Role = target.Role;
                        original.Salary = target.Salary;
                    }

                    return "";
                });


        }
   

       


        [TestMethod]
        public void Test_CanReturnEmployeeById()
        {
            Employee employee = MockEmployeeRepository.GetEmployeesDetail(1);

            Assert.IsNotNull(employee);
            Assert.IsInstanceOfType(employee, typeof(Employee));
            Assert.AreEqual("Venkatesh Kandregula", employee.Name);
        }



        [TestMethod]
        public void Test_CanInsertEmployee()
        {
            Employee newEmployee = new Employee()
            {Id = 4, Name = "Ramesh", Role = "Developer", Salary = 25000, };

            int employeeCount = this.MockEmployeeRepository.GetEmployeesDetailsList().Count;
            Assert.AreEqual(3, employeeCount);

            this.MockEmployeeRepository.SaveEmployeeDetails(newEmployee);

            employeeCount = this.MockEmployeeRepository.GetEmployeesDetailsList().Count;
            Assert.AreEqual(4, employeeCount);

            Employee testEmployee = this.MockEmployeeRepository.GetEmployeesDetail(3);
            Assert.IsNotNull(testEmployee);
            Assert.IsInstanceOfType(testEmployee, typeof(Employee));
            Assert.AreEqual("Charan Neermula", testEmployee.Name);
        }




        [TestMethod]
        public void CanUpdateEmployee()
        {
            Employee testEmployee = this.MockEmployeeRepository.GetEmployeesDetail(1);

            testEmployee.Name = "Venkatesh Kandregula";

            this.MockEmployeeRepository.SaveEmployeeDetails(testEmployee);

            Assert.AreEqual("Venkatesh Kandregula", this.MockEmployeeRepository.GetEmployeesDetail(1).Name);
        }

    }
}
